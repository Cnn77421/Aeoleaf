# 博客后台管理系统设计规范 - 需求拆解文档

## 产品概述

- **产品类型**: 设计规范文档站（Design System）
- **场景类型**: <scene_type>prototype-app</scene_type>
- **目标用户**: 设计师、前端开发者、产品经理
- **核心价值**: 为博客后台管理系统提供统一、可复用的设计语言与组件规范，确保产品视觉一致性
- **界面语言**: 中文
- **主题偏好**: user_specified（浅色简约、蓝青色调，与参考截图一致）
- **导航模式**: 锚点导航
- **导航布局**: Topbar（顶部）+ 侧边锚点目录（页面内）

---

## 页面结构总览

> **说明**：设计规范为单页文档站，采用锚点导航，所有章节在同一页面内纵向排列，配合左侧目录实现快速跳转

**页面文件**: `DesignSystemPage.tsx`

| 区块名称 | 锚点 | 区块说明 |
|---------|------|---------|
| 页头/Hero | `#hero` | 设计规范标题、版本号、简介 |
| 设计原则 | `#principles` | 核心设计理念与指导原则 |
| 色彩系统 | `#colors` | 主色、辅色、中性色、语义色板及使用规则 |
| 排版系统 | `#typography` | 字体族、字号层级、字重、行高规范 |
| 间距与栅格 | `#spacing` | 间距刻度、栅格系统、圆角、阴影 |
| 组件规范 | `#components` | 各组件实际样式展示 + 规格说明（核心区块） |
| 布局规范 | `#layout` | 页面框架、导航结构、响应式规则 |
| 交互规范 | `#interaction` | 状态反馈、动效、操作反馈规范 |

---

## 页面布局建议

- **布局模式**: 左右分栏（左侧固定目录 + 右侧内容流）—— 设计规范文档需要在各章节间频繁跳转，左侧目录提升查阅效率
- **视觉重心**: 内容 —— 核心在组件规范的实物展示和 token 数据呈现
- **结果承载区**: 不适用（内容展示型页面，无操作结果）
- **组件展示区**: 每个组件条目采用「组件实物预览区 + 规格说明区」双栏或上下结构，预览区展示实际渲染的组件样式，规格区列出尺寸/色值/状态等 token 数据

---

## 导航配置

- **导航布局**: Topbar（顶部主导航） + 左侧侧边目录（页面内锚点导航）
- **顶部导航项**（少量全局入口）:

  | 导航文字 | 锚点 |
  |---------|------|
  | 设计规范首页 | `#hero` |
  | 基础规范 | `#principles` |
  | 组件规范 | `#components` |
  | 布局与交互 | `#layout` |

- **左侧详细目录**（所有章节锚点）:

  | 目录层级 | 目录文字 | 锚点 |
  |---------|---------|------|
  | 一级 | 设计原则 | `#principles` |
  | 一级 | 色彩系统 | `#colors` |
  | 二级 | 主色与辅色 | `#colors-primary` |
  | 二级 | 中性色 | `#colors-neutral` |
  | 二级 | 语义色 | `#colors-semantic` |
  | 一级 | 排版系统 | `#typography` |
  | 一级 | 间距与栅格 | `#spacing` |
  | 一级 | 组件规范 | `#components` |
  | 二级 | 按钮 Button | `#comp-button` |
  | 二级 | 输入框 Input | `#comp-input` |
  | 二级 | 卡片 Card | `#comp-card` |
  | 二级 | 标签 Tag | `#comp-tag` |
  | 二级 | 表格 Table | `#comp-table` |
  | 二级 | 侧边栏 Sidebar | `#comp-sidebar` |
  | 二级 | 导航栏 Navbar | `#comp-navbar` |
  | 二级 | 标签页 Tabs | `#comp-tabs` |
  | 一级 | 布局规范 | `#layout` |
  | 一级 | 交互规范 | `#interaction` |

---

## 数据来源声明

| 数据/操作 | 来源类型 | 实现要求 | mock 兜底 |
|---|---|---|---|
| 设计 Token 数据（颜色/排版/间距/组件规格） | real-file | 从 `design-tokens.json` 读取，作为颜色板、排版样例、间距刻度、组件规格展示的数据源 | 初始 2-3 个 token 示例（source='mock'），完整数据来自 JSON 文件 |
| 参考截图视觉参照 | real-file | `reference.png` 作为视觉风格参照，用于校准色调、圆角、阴影等视觉细节，可在 Hero 区或设计原则区嵌入缩略图 | 无（截图为参考依据，不影响功能运行） |
| 组件样式渲染 | demo-mock | 组件规范中的按钮/输入框/卡片等组件实物，基于 design-tokens 的 token 值在页面中直接渲染（非图片，是真实 DOM 组件） | ✅ 本身即为按 token 渲染的示例组件 |

> 说明：核心数据来自 `design-tokens.json`（real-file），组件预览通过真实 React 组件渲染，样式严格遵循 token 中的数值。

---

## 功能列表

- **页面/区块**: Hero 页头
  - **页面目标**: 建立设计规范的第一印象，展示版本与概览
  - **功能点**:
    - **展示规范基本信息**: 标题、版本号、发布日期、适用范围简介
    - **展示参考截图缩略图**: 嵌入 `reference.png` 缩略图，点击可放大预览，作为设计溯源参考
    - **快速跳转入口**: 主要章节的快捷跳转按钮

- **页面/区块**: 设计原则
  - **页面目标**: 阐述设计理念与指导思想
  - **功能点**:
    - **原则卡片展示**: 3-4 条核心设计原则（如简约高效、一致性、可访问性等），每条配图标和简述

- **页面/区块**: 色彩系统
  - **页面目标**: 展示完整色板及使用规则
  - **功能点**:
    - **主色与辅色色板**: 从 `design-tokens.json` 读取颜色 token，以带色值标注的色块矩阵形式展示主色、辅色及各层级色阶
    - **中性色色板**: 展示灰阶系列（背景、边框、文字等）
    - **语义色色板**: 展示成功、警告、错误、信息四种状态色
    - **色值复制**: 点击色块复制 HEX/RGB 色值到剪贴板，toast 反馈成功

- **页面/区块**: 排版系统
  - **页面目标**: 展示字体层级与使用规范
  - **功能点**:
    - **字号层级展示**: 从 token 读取字号/行高/字重数据，以 H1-H6 + Body + Caption 层级展示实际效果与规格数值
    - **字体族说明**: 展示中文字体族、英文数字字体族及 fallback 顺序

- **页面/区块**: 间距与栅格
  - **页面目标**: 展示间距刻度、栅格规则、圆角、阴影等基础 token
  - **功能点**:
    - **间距刻度可视化**: 展示 4px 基准的间距刻度条（xs/sm/md/lg/xl/2xl 等），标注实际像素值
    - **圆角与阴影展示**: 从 token 读取圆角等级和阴影等级，以卡片实物对比展示
    - **栅格系统说明**: 12 栅格规则、列宽、 gutter 说明

- **页面/区块**: 组件规范（核心）
  - **页面目标**: 展示各组件的实际样式、状态变体与规格参数
  - **功能点**:
    - **按钮组件展示**: 渲染不同类型（主按钮/次按钮/文字按钮/危险按钮）、不同尺寸（大/中/小）、不同状态（默认/hover/disabled/loading）的真实按钮，并附规格说明（高度、圆角、padding、字号等，来自 token）
    - **输入框组件展示**: 渲染默认、聚焦、禁用、带图标、带错误状态的输入框，附规格说明
    - **卡片组件展示**: 渲染标准卡片（含标题区/内容区/操作区），展示阴影、圆角、内边距规格
    - **标签组件展示**: 渲染不同颜色语义（默认/成功/警告/错误/信息）的标签样式
    - **表格组件展示**: 渲染带表头、数据行、斑马纹、hover 态的示例表格
    - **侧边栏组件展示**: 渲染缩小版侧边栏示例（菜单、图标、激活态）
    - **导航栏组件展示**: 渲染顶部导航栏示例（Logo、菜单、用户头像）
    - **标签页组件展示**: 渲染 Tabs 切换效果（默认态/激活态/hover 态）
    - **组件规格参数表**: 每个组件下方附 token 数据表，列出关键尺寸、颜色、间距数值

- **页面/区块**: 布局规范
  - **页面目标**: 说明页面框架与响应式规则
  - **功能点**:
    - **布局框架示意图**: 以图形化方式展示 Sidebar + Header + Main Content 三段式布局结构，标注各区域宽度/高度
    - **响应式断点说明**: 列出桌面端断点与适配规则

- **页面/区块**: 交互规范
  - **页面目标**: 说明交互反馈与动效规范
  - **功能点**:
    - **状态反馈说明**: hover/active/focus/disabled 等状态的视觉反馈规则
    - **动效规范**: 过渡时长、缓动函数（来自 token），配按钮 hover 等可交互演示

---

## 数据共享配置

无跨页面数据共享需求（单页应用）。所有 token 数据通过页面内 state 统一管理，来源为 `design-tokens.json`。

```ts
// 设计 Token 类型定义（供 Code Agent 参考，实际字段以 JSON 文件为准）
interface IDesignTokens {
  colors: {
    primary: Record<string, string>;
    secondary: Record<string, string>;
    neutral: Record<string, string>;
    semantic: {
      success: string;
      warning: string;
      error: string;
      info: string;
    };
  };
  typography: {
    fontFamily: { sans: string; mono: string };
    fontSize: Record<string, string>;
    fontWeight: Record<string, number>;
    lineHeight: Record<string, string>;
  };
  spacing: Record<string, string>;
  radius: Record<string, string>;
  shadow: Record<string, string>;
  components: {
    button: { height: Record<string, string>; padding: Record<string, string>; borderRadius: string };
    input: { height: Record<string, string>; borderRadius: string };
    card: { padding: string; borderRadius: string; shadow: string };
    [key: string]: any;
  };
}

-------

<scene_type>prototype-app</scene_type>

# UI 设计指南

## 1. 设计推导依据

- **参考意图**: Exact Reference —— 从 reference.png 抽取视觉真相，颜色、字体气质、圆角、密度、布局节奏、组件形态均以截图为准；design-tokens.json 作为结构化数据来源。
- **核心情绪 / 应用类型**: 博客后台管理系统（app_type=1 中后台/工具），浅色简约、蓝青色调，传达清爽、高效、低干扰的写作与管理氛围。
- **独特记忆点**: 以蓝青色为主调的极简后台，侧栏纯白带细灰分隔，激活项用青蓝实心徽章式高亮；内容卡面极淡边框 + 极轻阴影，整体干净如写作纸页。

## 2. Art Direction

- **方向名**: 青瓷极简
- **Design Style**: Swiss Minimalist 瑞士极简 + Soft Blocks 柔色块 —— 博客后台需要长时间阅读与写作，极简结构降低视觉噪音；蓝青柔色块承担导航与状态提示，保持克制清爽。
- **DNA 参数**: 圆角 subtle（rounded-md） / 阴影 subtle（shadow-sm） / 间距 standard（gap-4 / p-6） / 字体方向 现代无衬线、中文清晰易读 / 装饰手法 细边框分隔 + 极轻卡片投影 + 青色点缀
- **应用类型**: Tool —— 左侧栏导航 + 顶部栏 + 右侧内容区的经典后台三段式布局。

## 3. Color System

**色彩关系**: 蓝青主色 + 极浅青灰辅助底 + 纸白背景 + 深墨文字，整体偏冷调清爽感。
**配色设计理由**: primary 蓝青色承担主行动、导航激活与品牌锚点；bg 纯白 + card 极浅灰营造纸张般的写作环境；accent 极浅青用于 hover/选中底，反馈柔和不刺眼；border 淡灰用于结构分隔，权重极低。
**主色推导**: 从参考截图中提取蓝青主色（约 hsl 195° 85% 55%），契合博客内容创作的清新、理性气质；比纯企业蓝更有文气，比纯青更有科技感。
**使用比例**: 65% 中性（bg / card / border / text） / 28% 辅助（accent / muted） / 7% primary；主按钮、导航激活、关键状态使用 primary，tab、链接、icon 使用 accent 或中性色以降权重。

| 角色 | CSS 变量 | Tailwind Class | HSL 值 | 设计说明 |
|---|---|---|---|---|
| bg | `--background` | `bg-background` | hsl(0 0% 100%) | 页面背景，纸白干净 |
| card | `--card` | `bg-card` | hsl(210 20% 98%) | 卡片、表单、弹层承载面 |
| text | `--foreground` | `text-foreground` | hsl(215 25% 18%) | 标题和正文，深墨高对比 |
| textMuted | `--muted-foreground` | `text-muted-foreground` | hsl(215 12% 48%) | 占位符、辅助元信息 |
| primary | `--primary` | `bg-primary` / `text-primary` | hsl(195 85% 52%) | 主交互、CTA、激活态、品牌识别 |
| primaryForeground | `--primary-foreground` | `text-primary-foreground` | hsl(0 0% 100%) | primary 上的文字和图标 |
| accent | `--accent` | `bg-accent` | hsl(195 70% 95%) | hover/focus 浅底、选中浅底、菜单项状态 |
| accentForeground | `--accent-foreground` | `text-accent-foreground` | hsl(195 75% 35%) | accent 上的文字和图标 |
| border | `--border` | `border-border` | hsl(214 15% 90%) | 输入框、卡片、菜单边界 |

**语义色提示**:
- 成功 success：hsl(160 70% 42%) —— bg: hsl(160 60% 95%) / border: hsl(160 55% 85%) / text: hsl(160 70% 32%)；饱和度与 primary 对齐，偏青绿保持冷调统一。
- 警告 warning：hsl(38 90% 55%) —— bg: hsl(40 85% 95%) / border: hsl(38 80% 85%) / text: hsl(28 85% 35%)；暖色但降饱和，避免突兀。
- 错误 danger：hsl(0 75% 58%) —— bg: hsl(0 70% 96%) / border: hsl(0 65% 88%) / text: hsl(0 70% 42%)；饱和度与 primary 接近，不出现超饱和刺眼红。

## 4. 字体与节奏

- **font-display**: Inter + Noto Sans SC —— 现代无衬线，几何感强，标题清晰利落，与蓝青极简气质匹配。
- **font-body**: Inter + Noto Sans SC —— 中后台长文阅读与数据展示需高可读性，字幅均匀、层级分明。
- **字号**: H1 text-3xl ~ text-4xl；H2 text-xl ~ text-2xl；H3 text-lg；body text-base（14-16px）；muted text-sm。
- **圆角**: 中（rounded-md, 6-8px）—— 参考截图中按钮、卡片、输入框均为微圆角，兼顾现代感与工具理性。

## 5. 全局布局契约

- **Reference Layout Use**: 三段式布局（左侧栏 + 顶栏 + 内容区）来自参考截图；侧栏宽度、顶栏高度、内容卡片密度忠实还原。
- **Page / Section Order**: 设计规范页按「设计原则 → 色彩系统 → 排版系统 → 间距与栅格 → 组件规范 → 布局规范 → 交互规范」顺序组织，左侧锚点导航。
- **Standard Content Zone**: 后台内容区 `max-w-[1400px]` + `mx-auto`，设计规范页内容主体 `max-w-5xl` + `mx-auto`，组件演示区可全宽展示。
- **Shell / Frame Alignment**: 同宽 —— 内容容器与框架共享网格节奏，padding 对齐 8px 基线。
- **Padding & Rhythm**: `px-4 md:px-6 lg:px-8 py-8 md:py-10`，章节间距 `space-y-12`，卡片间距 `gap-4`。
- **Full-bleed Zones**: 组件演示区域（按钮、表格、侧边栏预览）可突破内容区宽度全宽展示，文字说明仍受内容区约束。
- **Local Narrowing**: 设计原则、交互规范等纯文字章节收窄至 `max-w-3xl`，提升阅读舒适度。
- **Overflow Strategy**: 组件演示中的表格、侧边栏预览使用 `overflow-x-auto`，代码块横向滚动。
- **Flexibility Boundary**: 允许移动端侧栏折叠、卡片内边距压缩、章节间距微调；不允许改变主色、圆角、阴影语言和字体系统。

## 6. 视觉与动效

- **装饰**: 细边框分隔 + 极轻卡片投影 + 青色小面积点缀
- **阴影/边界**: 轻 —— 卡片 shadow-sm + 1px border，hover 时阴影略加深（shadow-md），边界始终可见
- **动效**: 克制 —— hover / active / focus 用 150ms 过渡，颜色与透明度变化为主；无夸张位移或弹性动效；页面切换淡入淡出

## 7. 组件原则

- 按钮、输入框、卡片、标签、表格、侧边栏、导航栏、标签页均需展示 Default / Hover / Active / Focus / Disabled 五种状态。
- Primary 按钮承担主行动，实心蓝青填充；Secondary / Outline 用边框 + 透明底；Ghost 按钮纯文字 + accent 底承接 hover。
- 输入框默认淡灰边框，focus 时 border-primary + 极淡 primary 光晕（ring-2 ring-primary/20）。
- 卡片统一 bg-card + border-border + rounded-md + shadow-sm，内部间距 p-6。
- 标签（Tag）使用 accent 底 + accentForeground 文字 + rounded-full，小号 pill 形态。
- 表格使用极简横线分隔，无竖线，hover 行 bg-accent/50。
- 侧边栏菜单项激活态使用 bg-primary + text-primaryForeground，圆角 pill 或 md，左侧无竖线指示。
- 加载与空状态延续蓝青极简语言，使用同色系插画或图标，不使用默认菊花加载。

## 8. Image Direction

- **Image Role**: 无强制图片需求，优先通过排版、色彩和组件样式建立视觉记忆点；组件演示以真实组件渲染为主。
- **Image Art Direction**: 无强制图片需求
- **Image Prompt Keywords**: 无
- **Image Avoidance**: 避免通用商务人物素材、无意义抽象渐变、低质感图标库拼接图

## 9. Anti-patterns

- **Split personality**: 规范页与后台实际界面使用两套视觉语言；设计规范必须是后台系统的镜像映射。
- **Phantom tokens**: 编造不存在的 CSS 变量或 Tailwind class；所有 token 必须在 design-tokens.json 基础上定义或扩展。
- **Default SaaS drift**: 回到默认深蓝按钮、紫色渐变和厚重卡片；必须坚持蓝青主调 + 极轻阴影 + 细边框的青瓷极简语言。
- **Invisible interaction**: 只做 hover 忽略 focus-visible；每个可交互元素都要有清晰的键盘焦点态（ring 或 border 变化）。
- **Mono-hue tyranny**: 主色同时铺满按钮、tab、icon、边框、链接、表格表头；按 65-28-7 比例把 primary 收回到 CTA 与导航激活，其余用 accent / 中性色。
- **Status color drift**: 成功/警告/错误饱和度远高于主色，导致状态色刺眼；语义色饱和度必须与 primary 对齐 ±15%。
- **Demo-only aesthetics**: 组件演示为了好看而与实际后台使用状态不一致；规范中的组件样式必须可直接复用到生产环境。