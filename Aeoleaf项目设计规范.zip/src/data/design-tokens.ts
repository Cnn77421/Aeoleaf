// EXPORTS: IDesignTokens, DESIGN_TOKENS

export interface IDesignTokens {
  colors: {
    primary: Record<string, string>;
    secondary: Record<string, string>;
    neutral: Record<string, string>;
    semantic: {
      success: string;
      warning: string;
      error: string;
      info: string;
    };
    dark: {
      background: string;
      card: string;
      popover: string;
      foreground: string;
      mutedForeground: string;
      disabledForeground: string;
      border: string;
      divider: string;
      primary: string;
      primaryForeground: string;
      semantic: {
        emphasis: string;
        secondary: string;
        muted: string;
        strong: string;
      };
    };
  };
  typography: {
    fontFamily: { sans: string; mono: string };
    fontSize: Record<string, string>;
    fontWeight: Record<string, number>;
    lineHeight: Record<string, string>;
  };
  spacing: Record<string, string>;
  radius: Record<string, string>;
  shadow: Record<string, string>;
  components: {
    button: {
      height: Record<string, string>;
      padding: Record<string, string>;
      borderRadius: string;
      fontSize: Record<string, string>;
    };
    input: {
      height: Record<string, string>;
      borderRadius: string;
      padding: string;
    };
    card: {
      padding: string;
      borderRadius: string;
      shadow: string;
    };
    tag: {
      height: string;
      padding: string;
      borderRadius: string;
      fontSize: string;
    };
    table: {
      rowHeight: string;
      headerBg: string;
      borderRadius: string;
    };
    sidebar: {
      width: string;
      collapsedWidth: string;
      itemHeight: string;
      bg: string;
    };
    navbar: {
      height: string;
      bg: string;
      shadow: string;
    };
    tabs: {
      itemHeight: string;
      indicatorHeight: string;
      fontSize: string;
    };
    dropdown: {
      minWidth: string;
      padding: string;
      borderRadius: string;
      itemHeight: string;
      itemPadding: string;
      separatorColor: string;
    };
    modal: {
      borderRadius: string;
      padding: string;
      headerHeight: string;
      footerHeight: string;
      sizes: { sm: string; md: string; lg: string };
      maskOpacity: string;
    };
    pagination: {
      itemSize: string;
      itemBorderRadius: string;
      itemGap: string;
      fontSize: string;
    };
    breadcrumb: {
      fontSize: string;
      itemHeight: string;
      separatorGap: string;
    };
    switch: {
      width: string;
      height: string;
      thumbSize: string;
      borderRadius: string;
      transitionDuration: string;
    };
    checkbox: {
      size: string;
      borderRadius: string;
      borderWidth: string;
    };
    tooltip: {
      padding: string;
      borderRadius: string;
      fontSize: string;
      arrowSize: string;
      offset: string;
    };
    empty: {
      iconSize: string;
      titleSize: string;
      descriptionSize: string;
      gap: string;
    };
    loading: {
      spinnerSize: string;
      spinnerStrokeWidth: string;
      skeletonRadius: string;
    };
    notificationBadge: {
      dotSize: string;
      numberMinWidth: string;
      numberHeight: string;
      numberPadding: string;
      fontSize: string;
      borderRadius: string;
    };
  };
  motion: {
    duration: Record<string, string>;
    easing: string;
  };
  grid: {
    columns: number;
    gutter: string;
    margin: string;
    maxWidth: string;
  };
}

// 设计 Token —— 基于蓝青色调 + 浅色简约风格
export const DESIGN_TOKENS: IDesignTokens = {
  colors: {
    primary: {
      '50': '#FAFAFA',
      '100': '#F5F5F5',
      '200': '#E5E5E5',
      '300': '#D4D4D4',
      '400': '#A3A3A3',
      '500': '#737373',
      '600': '#525252',
      '700': '#404040',
      '800': '#262626',
      '900': '#171717',
    },
    secondary: {
      '50': '#FAFAFA',
      '100': '#F0F0F0',
      '200': '#E0E0E0',
      '300': '#CFCFCF',
      '400': '#A8A8A8',
      '500': '#787878',
      '600': '#575757',
      '700': '#424242',
      '800': '#2A2A2A',
      '900': '#1A1A1A',
    },
    neutral: {
      '50': '#FAFAFA',
      '100': '#F5F5F5',
      '200': '#E8E8E8',
      '300': '#D9D9D9',
      '400': '#BFBFBF',
      '500': '#8C8C8C',
      '600': '#595959',
      '700': '#434343',
      '800': '#262626',
      '900': '#1F1F1F',
    },
    semantic: {
      success: '#262626',
      warning: '#737373',
      error: '#0A0A0A',
      info: '#404040',
    },
    dark: {
      background: '#121212',
      card: '#1A1A1A',
      popover: '#1F1F1F',
      foreground: '#F2F2F2',
      mutedForeground: '#999999',
      disabledForeground: '#525252',
      border: '#2E2E2E',
      divider: '#262626',
      primary: '#F2F2F2',
      primaryForeground: '#121212',
      semantic: {
        emphasis: '#D9D9D9',
        secondary: '#A3A3A3',
        muted: '#737373',
        strong: '#FAFAFA',
      },
    },
  },
  typography: {
    fontFamily: {
      sans: "'Inter', 'PingFang SC', 'Microsoft YaHei', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      mono: "'SF Mono', 'Monaco', 'Inconsolata', 'Fira Code', monospace",
    },
    fontSize: {
      'display-1': '42px',
      'display-2': '34px',
      'h1': '30px',
      'h2': '24px',
      'h3': '20px',
      'h4': '18px',
      'h5': '16px',
      'h6': '14px',
      'body-lg': '16px',
      'body': '14px',
      'body-sm': '13px',
      'caption': '12px',
      'xs': '11px',
    },
    fontWeight: {
      light: 300,
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
    lineHeight: {
      tight: '1.2',
      normal: '1.5',
      relaxed: '1.6',
      loose: '1.8',
    },
  },
  spacing: {
    '0': '0px',
    'xs': '4px',
    'sm': '8px',
    'md': '12px',
    'base': '16px',
    'lg': '20px',
    'xl': '24px',
    '2xl': '32px',
    '3xl': '40px',
    '4xl': '48px',
    '5xl': '64px',
  },
  radius: {
    none: '0px',
    sm: '2px',
    base: '4px',
    md: '6px',
    lg: '8px',
    xl: '12px',
    full: '9999px',
  },
  shadow: {
    none: 'none',
    xs: '0 1px 2px 0 rgba(0, 0, 0, 0.03)',
    sm: '0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)',
    base: '0 4px 6px -1px rgba(0, 0, 0, 0.06), 0 2px 4px -2px rgba(0, 0, 0, 0.06)',
    md: '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.08)',
    lg: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
  },
  components: {
    button: {
      height: { sm: '28px', md: '36px', lg: '44px' },
      padding: { sm: '0 12px', md: '0 16px', lg: '0 20px' },
      borderRadius: '6px',
      fontSize: { sm: '12px', md: '14px', lg: '16px' },
    },
    input: {
      height: { sm: '28px', md: '36px', lg: '44px' },
      borderRadius: '6px',
      padding: '0 12px',
    },
    card: {
      padding: '20px',
      borderRadius: '8px',
      shadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)',
    },
    tag: {
      height: '22px',
      padding: '0 8px',
      borderRadius: '4px',
      fontSize: '12px',
    },
    table: {
      rowHeight: '48px',
      headerBg: '#FAFAFA',
      borderRadius: '8px',
    },
    sidebar: {
      width: '240px',
      collapsedWidth: '64px',
      itemHeight: '44px',
      bg: '#FFFFFF',
    },
    navbar: {
      height: '56px',
      bg: '#FFFFFF',
      shadow: '0 1px 2px 0 rgba(0, 0, 0, 0.04)',
    },
    tabs: {
      itemHeight: '40px',
      indicatorHeight: '2px',
      fontSize: '14px',
    },
    dropdown: {
      minWidth: '160px',
      padding: '4px',
      borderRadius: '8px',
      itemHeight: '36px',
      itemPadding: '0 12px',
      separatorColor: '#E5E5E5',
    },
    modal: {
      borderRadius: '8px',
      padding: '24px',
      headerHeight: '56px',
      footerHeight: '60px',
      sizes: { sm: '400px', md: '600px', lg: '800px' },
      maskOpacity: '0.5',
    },
    pagination: {
      itemSize: '32px',
      itemBorderRadius: '6px',
      itemGap: '4px',
      fontSize: '14px',
    },
    breadcrumb: {
      fontSize: '14px',
      itemHeight: '24px',
      separatorGap: '8px',
    },
    switch: {
      width: '44px',
      height: '24px',
      thumbSize: '18px',
      borderRadius: '24px',
      transitionDuration: '200ms',
    },
    checkbox: {
      size: '16px',
      borderRadius: '3px',
      borderWidth: '1.5px',
    },
    tooltip: {
      padding: '6px 10px',
      borderRadius: '4px',
      fontSize: '12px',
      arrowSize: '6px',
      offset: '8px',
    },
    empty: {
      iconSize: '80px',
      titleSize: '16px',
      descriptionSize: '14px',
      gap: '16px',
    },
    loading: {
      spinnerSize: '24px',
      spinnerStrokeWidth: '3px',
      skeletonRadius: '4px',
    },
    notificationBadge: {
      dotSize: '8px',
      numberMinWidth: '18px',
      numberHeight: '18px',
      numberPadding: '0 5px',
      fontSize: '11px',
      borderRadius: '9px',
    },
  },
  motion: {
    duration: {
      fast: '150ms',
      base: '250ms',
      slow: '400ms',
    },
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
  },
  grid: {
    columns: 12,
    gutter: '16px',
    margin: '24px',
    maxWidth: '1440px',
  },
};
