import { Palette, Menu, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ThemeToggle from '@/components/ThemeToggle';

interface DesignTopbarProps {
  onToggleSidebar: () => void;
}

export default function DesignTopbar({ onToggleSidebar }: DesignTopbarProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="flex h-14 items-center gap-4 px-4 md:px-6">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={onToggleSidebar}
          aria-label="切换目录"
        >
          <Menu className="size-5" />
        </Button>

        <div className="flex items-center gap-2">
          <div className="flex size-8 items-center justify-center rounded-md bg-foreground text-background">
            <Palette className="size-4" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold text-foreground">博客后台设计系统</div>
            <div className="text-xs text-muted-foreground">Blog Admin Design System v1.0</div>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-3">
          <ThemeToggle />
          <div className="relative hidden md:block w-64">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="搜索组件或 Token"
              className="h-9 bg-muted/50 pl-9 text-sm"
            />
          </div>
          <div className="text-xs text-muted-foreground hidden lg:block">
            v1.0.0 · 单色主题
          </div>
        </div>
      </div>
    </header>
  );
}
