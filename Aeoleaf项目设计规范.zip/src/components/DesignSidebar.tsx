import { NavLink } from '@lark-apaas/client-toolkit-lite';
import {
  Layers,
  Palette,
  Type,
  Grid3X3,
  Boxes,
  LayoutDashboard,
  MousePointerClick,
  Sparkles,
  X,
  Moon,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV_GROUPS = [
  {
    title: '开始',
    items: [
      { id: 'hero', label: '概览', icon: Sparkles },
    ],
  },
  {
    title: '基础规范',
    items: [
      { id: 'principles', label: '设计原则', icon: Layers },
      { id: 'colors', label: '色彩系统', icon: Palette },
      { id: 'typography', label: '排版系统', icon: Type },
      { id: 'spacing', label: '间距与栅格', icon: Grid3X3 },
    ],
  },
  {
    title: '组件规范',
    items: [
      { id: 'components', label: '组件总览', icon: Boxes },
    ],
    subItems: [
      { id: 'comp-button', label: '按钮 Button' },
      { id: 'comp-input', label: '输入框 Input' },
      { id: 'comp-card', label: '卡片 Card' },
      { id: 'comp-tag', label: '标签 Tag' },
      { id: 'comp-table', label: '表格 Table' },
      { id: 'comp-sidebar', label: '侧边栏 Sidebar' },
      { id: 'comp-navbar', label: '导航栏 Navbar' },
      { id: 'comp-tabs', label: '标签页 Tabs' },
      { id: 'comp-dropdown', label: '下拉菜单 Dropdown' },
      { id: 'comp-modal', label: '弹窗 Modal' },
      { id: 'comp-pagination', label: '分页 Pagination' },
      { id: 'comp-breadcrumb', label: '面包屑 Breadcrumb' },
      { id: 'comp-switch', label: '开关 Switch' },
      { id: 'comp-checkbox-radio', label: '复选框 & 单选框' },
      { id: 'comp-tooltip', label: '提示气泡 Tooltip' },
      { id: 'comp-empty', label: '空状态 Empty' },
      { id: 'comp-loading', label: '加载状态 Loading' },
      { id: 'comp-badge-notification', label: '通知徽标 Badge' },
    ],
  },
  {
    title: '模式规范',
    items: [
      { id: 'layout', label: '布局规范', icon: LayoutDashboard },
      { id: 'interaction', label: '交互规范', icon: MousePointerClick },
      { id: 'dark-mode', label: '深色模式', icon: Moon },
    ],
  },
];

interface DesignSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DesignSidebar({ isOpen, onClose }: DesignSidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-foreground/20 backdrop-blur-sm md:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={cn(
          'fixed left-0 top-14 z-50 h-[calc(100vh-3.5rem)] w-64 shrink-0 border-r border-border/50 bg-card/60 backdrop-blur-sm transition-transform duration-300 md:sticky md:top-14 md:z-0 md:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between px-4 py-3 md:hidden">
            <span className="text-sm font-medium text-foreground">目录</span>
            <button
              onClick={onClose}
              className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
              aria-label="关闭目录"
            >
              <X className="size-4" />
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto px-3 py-4">
            {NAV_GROUPS.map((group) => (
              <div key={group.title} className="mb-5">
                <div className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground/70">
                  {group.title}
                </div>
                <ul className="space-y-0.5">
                  {group.items.map((item) => {
                    const Icon = item.icon;
                    return (
                      <li key={item.id}>
                        <NavLink
                          to={`#${item.id}`}
                          className={({ isActive }) =>
                            cn(
                              'flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors',
                              isActive
                                ? 'bg-primary/10 font-medium text-primary'
                                : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                            )
                          }
                          onClick={onClose}
                        >
                          <Icon className="size-4 shrink-0" />
                          <span>{item.label}</span>
                        </NavLink>
                      </li>
                    );
                  })}
                  {group.subItems && (
                    <ul className="ml-6 mt-1 space-y-0.5 border-l border-border/50 pl-3">
                      {group.subItems.map((item) => (
                        <li key={item.id}>
                          <NavLink
                            to={`#${item.id}`}
                            className={({ isActive }) =>
                              cn(
                                'block rounded-md px-2.5 py-1.5 text-[13px] transition-colors',
                                isActive
                                  ? 'bg-primary/10 font-medium text-primary'
                                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                              )
                            }
                            onClick={onClose}
                          >
                            {item.label}
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  )}
                </ul>
              </div>
            ))}
          </nav>

          <div className="border-t border-border/50 px-4 py-3">
            <div className="text-xs text-muted-foreground">
              © 2024 Blog Admin DS
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
