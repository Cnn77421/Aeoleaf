import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import DesignTopbar from '@/components/DesignTopbar';
import DesignSidebar from '@/components/DesignSidebar';
import { ThemeProvider } from '@/components/ThemeProvider';

export const Layout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <ThemeProvider>
      <div className="flex min-h-screen flex-col bg-background">
        <DesignTopbar onToggleSidebar={() => setSidebarOpen((v) => !v)} />
        <div className="flex flex-1 min-w-0">
          <DesignSidebar
            isOpen={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
          />
          <main className="flex-1 min-w-0">
            <Outlet />
          </main>
        </div>
      </div>
    </ThemeProvider>
  );
};
