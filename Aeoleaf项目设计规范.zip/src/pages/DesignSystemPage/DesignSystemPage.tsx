import HeroSection from './sections/HeroSection';
import PrinciplesSection from './sections/PrinciplesSection';
import ColorsSection from './sections/ColorsSection';
import TypographySection from './sections/TypographySection';
import SpacingSection from './sections/SpacingSection';
import ComponentsSection from './sections/ComponentsSection';
import LayoutSection from './sections/LayoutSection';
import InteractionSection from './sections/InteractionSection';
import DarkModeSection from './sections/DarkModeSection';
import FooterSection from './sections/FooterSection';

export default function DesignSystemPage() {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <PrinciplesSection />
      <ColorsSection />
      <TypographySection />
      <SpacingSection />
      <ComponentsSection />
      <LayoutSection />
        <InteractionSection />
        <DarkModeSection />
        <FooterSection />
    </div>
  );
}
