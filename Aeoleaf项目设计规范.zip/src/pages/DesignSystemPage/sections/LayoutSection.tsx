import { motion } from 'framer-motion';
import { LayoutDashboard, Monitor, Tablet, Smartphone } from 'lucide-react';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

const BREAKPOINTS = [
  { name: '移动端', icon: Smartphone, width: '< 768px', cols: 4, desc: '单列或双列布局，底部导航' },
  { name: '平板端', icon: Tablet, width: '768px - 1024px', cols: 8, desc: '折叠侧边栏，紧凑布局' },
  { name: '桌面端', icon: Monitor, width: '1024px - 1440px', cols: 12, desc: '完整侧边栏，标准布局' },
  { name: '大屏', icon: Monitor, width: '> 1440px', cols: 12, desc: '最大宽度 1440px，居中显示' },
];

export default function LayoutSection() {
  return (
    <section id="layout" className="w-full border-t border-border/50 bg-muted/20 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Layout"
          title="布局规范"
          description="标准化的页面框架与响应式规则，确保在不同设备上都能提供一致且高效的使用体验。"
        />

        {/* 布局框架 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">页面框架 · Page Layout</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            后台系统采用侧边栏 + 顶部导航 + 主内容区的经典三段式布局，结构清晰、易于扩展。
          </p>

          <div className="rounded-xl border border-border/60 bg-card p-6">
            {/* 布局示意图 */}
            <div className="flex h-64 gap-3">
              {/* 侧边栏 */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                className="flex w-40 shrink-0 flex-col gap-2 rounded-lg bg-foreground/5 p-3 border border-foreground/10"
              >
                <div className="flex items-center gap-2 text-xs font-medium text-foreground">
                  <LayoutDashboard className="size-3.5" />
                  Sidebar
                </div>
                <div className="space-y-1.5">
                  {['菜单项', '菜单项', '菜单项', '菜单项'].map((m, i) => (
                    <div
                      key={i}
                      className={`rounded px-2 py-1 text-[10px] ${
                        i === 0 ? 'bg-foreground text-background font-medium' : 'text-muted-foreground'
                      }`}
                    >
                      {m}
                    </div>
                  ))}
                </div>
                <div className="mt-auto text-[10px] text-muted-foreground font-mono">
                  {DESIGN_TOKENS.components.sidebar.width}
                </div>
              </motion.div>

              {/* 右侧主区 */}
              <div className="flex flex-1 flex-col gap-2">
                {/* 顶栏 */}
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
                  className="flex h-10 items-center justify-between rounded-lg bg-card border border-border/60 px-3 shadow-sm"
                >
                  <div className="text-xs font-medium text-foreground">Navbar</div>
                  <div className="flex items-center gap-1.5">
                    <div className="size-4 rounded-full bg-muted" />
                  </div>
                </motion.div>

                {/* 内容区 */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                  className="flex-1 rounded-lg bg-muted/40 border border-dashed border-border/60 p-3"
                >
                  <div className="grid grid-cols-4 gap-2">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="h-8 rounded bg-background border border-border/40" />
                    ))}
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    <div className="h-16 col-span-2 rounded bg-background border border-border/40" />
                    <div className="h-16 rounded bg-background border border-border/40" />
                  </div>
                  <div className="mt-2 text-[10px] text-muted-foreground text-center">
                    Main Content · 12 columns
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>

        {/* 响应式断点 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">响应式断点 · Breakpoints</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            采用移动优先的响应式设计策略，在不同屏幕尺寸下自动适配最佳布局。
          </p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {BREAKPOINTS.map((bp, i) => {
              const Icon = bp.icon;
              return (
                <motion.div
                  key={bp.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.4, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                  className="rounded-xl border border-border/60 bg-card p-5"
                >
                  <div className="mb-3 flex size-10 items-center justify-center rounded-lg bg-foreground/10 text-foreground">
                    <Icon className="size-5" />
                  </div>
                  <div className="text-sm font-semibold text-foreground">{bp.name}</div>
                  <div className="mt-1 font-mono text-xs text-foreground/70">{bp.width}</div>
                  <div className="mt-3 text-xs text-muted-foreground">{bp.desc}</div>
                  <div className="mt-3 flex items-center gap-1">
                    {Array.from({ length: bp.cols / 2 }).map((_, j) => (
                      <div key={j} className="h-1.5 flex-1 rounded-full bg-foreground/30" />
                    ))}
                    <span className="ml-2 text-[10px] text-muted-foreground">{bp.cols} 列</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
