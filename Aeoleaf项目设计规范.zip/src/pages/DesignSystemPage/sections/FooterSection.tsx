import { Palette, Heart } from 'lucide-react';

export default function FooterSection() {
  return (
    <footer className="w-full border-t border-border/50 bg-card/50">
      <div className="mx-auto max-w-5xl px-4 py-8 md:px-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <div className="flex size-7 items-center justify-center rounded-md bg-foreground text-background">
              <Palette className="size-3.5" />
            </div>
            <span className="text-sm font-medium text-foreground">博客后台设计系统</span>
          </div>

          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span>用</span>
            <Heart className="size-3 fill-foreground text-foreground" />
            <span>打造 · v1.0.0</span>
          </div>

          <div className="text-xs text-muted-foreground">
            © 2024 Blog Admin Design System
          </div>
        </div>
      </div>
    </footer>
  );
}
