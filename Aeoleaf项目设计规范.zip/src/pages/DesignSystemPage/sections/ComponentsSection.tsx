import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Loader2, Plus, Trash2, Edit, Eye } from 'lucide-react';
import {
  Button
} from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';
import MoreComponentsSection from './MoreComponentsSection';

// 规格表格组件
function SpecTable({ rows }: { rows: { token: string; value: string }[] }) {
  return (
    <div className="overflow-hidden rounded-lg border border-border/60">
      <table className="w-full text-sm">
        <thead className="bg-muted/40">
          <tr>
            <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">Token</th>
            <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">Value</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.token} className="border-t border-border/40">
              <td className="px-3 py-2 font-mono text-xs text-foreground">{r.token}</td>
              <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{r.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ComponentBlock({ id, title, description, children, specs }: {
  id: string;
  title: string;
  description: string;
  children: React.ReactNode;
  specs: { token: string; value: string }[];
}) {
  return (
    <div id={id} className="scroll-mt-20 rounded-xl border border-border/60 bg-card overflow-hidden">
      <div className="border-b border-border/60 p-5">
        <h4 className="text-base font-semibold text-foreground">{title}</h4>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
      <div className="flex flex-col lg:flex-row">
        <div className="flex-1 p-6 bg-muted/20 flex items-center justify-center min-h-[180px]">
          {children}
        </div>
        <div className="w-full border-t border-border/60 p-4 lg:w-64 lg:border-l lg:border-t-0 lg:p-5">
          <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">规格</div>
          <SpecTable rows={specs} />
        </div>
      </div>
    </div>
  );
}

function ButtonDemo() {
  const [loading, setLoading] = useState(false);

  const handleLoading = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1200);
  };

  return (
    <div className="flex flex-wrap items-center gap-3">
      <Button>主按钮</Button>
      <Button variant="secondary">次按钮</Button>
      <Button variant="outline">描边按钮</Button>
      <Button variant="ghost">幽灵按钮</Button>
      <Button variant="destructive">深色按钮</Button>
      <Button variant="outline" size="sm">小号</Button>
      <Button size="lg">大号</Button>
      <Button disabled>禁用</Button>
      <Button onClick={handleLoading} disabled={loading}>
        {loading ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Plus className="mr-2 size-4" />}
        {loading ? '加载中' : '带图标'}
      </Button>
    </div>
  );
}

function InputDemo() {
  return (
    <div className="w-full max-w-md space-y-4">
      <Input placeholder="默认输入框" />
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="带图标的输入框" className="pl-9" />
      </div>
      <Input placeholder="禁用状态" disabled />
      <Input placeholder="错误状态" className="border-destructive focus-visible:ring-destructive" />
      <Input defaultValue="带清除按钮" />
    </div>
  );
}

function CardDemo() {
  return (
    <div className="grid w-full max-w-md gap-4 sm:grid-cols-2">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-base">文章统计</CardTitle>
          <CardDescription>本月发布数据</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-foreground">128</div>
          <div className="mt-1 text-xs text-foreground">↑ 12.5% 较上月</div>
        </CardContent>
        <CardFooter className="text-xs text-muted-foreground">
          更新于 5 分钟前
        </CardFooter>
      </Card>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-base">用户活跃</CardTitle>
          <CardDescription>今日访问统计</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-foreground">1,248</div>
          <div className="mt-1 text-xs text-muted-foreground">↓ 3.2% 较昨日</div>
        </CardContent>
        <CardFooter className="text-xs text-muted-foreground">
          更新于 10 分钟前
        </CardFooter>
      </Card>
    </div>
  );
}

function TagDemo() {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Badge>默认</Badge>
      <Badge variant="secondary">次要</Badge>
      <Badge variant="outline">描边</Badge>
      <Badge variant="destructive">深色</Badge>
      <Badge className="bg-foreground/80 text-background hover:bg-foreground/90">强调</Badge>
      <Badge className="bg-muted text-foreground hover:bg-muted/80">浅灰</Badge>
      <Badge className="bg-foreground/30 text-background hover:bg-foreground/40">中灰</Badge>
      <Badge className="border border-foreground/30 text-foreground">轮廓</Badge>
    </div>
  );
}

function TableDemo() {
  const data = [
    { id: 1, title: 'React 19 新特性解析', author: '张三', status: '已发布', date: '2024-01-15', views: 1248 },
    { id: 2, title: 'Tailwind CSS 4.0 深度指南', author: '李四', status: '草稿', date: '2024-01-14', views: 0 },
    { id: 3, title: '博客 SEO 优化最佳实践', author: '王五', status: '已发布', date: '2024-01-13', views: 856 },
    { id: 4, title: '前端性能优化手册', author: '赵六', status: '审核中', date: '2024-01-12', views: 0 },
  ];

  return (
    <div className="w-full max-w-3xl overflow-hidden rounded-lg border border-border/60">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/40 hover:bg-muted/40">
            <TableHead className="font-medium">文章标题</TableHead>
            <TableHead className="font-medium">作者</TableHead>
            <TableHead className="font-medium">状态</TableHead>
            <TableHead className="font-medium">浏览量</TableHead>
            <TableHead className="font-medium text-right">操作</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((row) => (
            <TableRow key={row.id}>
              <TableCell className="font-medium">{row.title}</TableCell>
              <TableCell className="text-muted-foreground">{row.author}</TableCell>
              <TableCell>
                <Badge
                  variant={row.status === '已发布' ? 'default' : row.status === '草稿' ? 'secondary' : 'outline'}
                >
                  {row.status}
                </Badge>
              </TableCell>
              <TableCell className="tabular-nums">{row.views.toLocaleString()}</TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7">
                    <Eye className="size-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7">
                    <Edit className="size-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive">
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function SidebarDemo() {
  const menuItems = [
    { label: '仪表盘', active: true },
    { label: '文章管理', active: false },
    { label: '分类管理', active: false },
    { label: '用户管理', active: false },
    { label: '系统设置', active: false },
  ];

  return (
    <div className="flex w-full max-w-sm items-stretch gap-4">
      <div className="w-56 shrink-0 rounded-lg border border-border/60 bg-background shadow-sm overflow-hidden">
        <div className="border-b border-border/60 px-4 py-3">
          <div className="text-sm font-semibold text-foreground">博客后台</div>
        </div>
        <nav className="p-2">
          {menuItems.map((item) => (
            <div
              key={item.label}
              className={`flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors ${
                item.active
                  ? 'bg-foreground text-background font-medium'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              <span className="size-4 flex items-center justify-center">
                <span className={`size-1.5 rounded-full ${item.active ? 'bg-background' : 'bg-muted-foreground/40'}`} />
              </span>
              <span>{item.label}</span>
            </div>
          ))}
        </nav>
      </div>
      <div className="flex-1 rounded-lg border border-dashed border-border/60 bg-muted/10 flex items-center justify-center">
        <span className="text-xs text-muted-foreground">主内容区</span>
      </div>
    </div>
  );
}

function NavbarDemo() {
  return (
    <div className="w-full max-w-2xl rounded-lg border border-border/60 bg-background shadow-sm overflow-hidden">
      <div className="flex h-14 items-center gap-4 px-4 border-b border-border/60">
        <div className="flex items-center gap-2">
          <div className="size-7 rounded-md bg-foreground flex items-center justify-center text-background text-xs font-bold">B</div>
          <span className="text-sm font-semibold text-foreground">Blog Admin</span>
        </div>
        <nav className="ml-6 hidden md:flex items-center gap-1">
          {['仪表盘', '文章', '用户', '设置'].map((item, i) => (
            <div
              key={item}
              className={`px-3 py-1.5 text-sm rounded-md ${
                i === 0 ? 'text-background font-medium bg-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {item}
            </div>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <div className="size-7 rounded-full bg-muted flex items-center justify-center text-xs font-medium text-foreground">A</div>
        </div>
      </div>
      <div className="flex items-center justify-center h-20 bg-muted/10">
        <span className="text-xs text-muted-foreground">页面内容</span>
      </div>
    </div>
  );
}

function TabsDemo() {
  return (
    <div className="w-full max-w-md">
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">概览</TabsTrigger>
          <TabsTrigger value="articles">文章</TabsTrigger>
          <TabsTrigger value="settings">设置</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="mt-4 rounded-lg border border-border/60 p-4 bg-card">
          <p className="text-sm text-foreground">这是概览标签页的内容区域。</p>
          <p className="mt-2 text-xs text-muted-foreground">标签页用于在同一页面内组织不同类别的信息。</p>
        </TabsContent>
        <TabsContent value="articles" className="mt-4 rounded-lg border border-border/60 p-4 bg-card">
          <p className="text-sm text-foreground">文章管理内容区域。</p>
        </TabsContent>
        <TabsContent value="settings" className="mt-4 rounded-lg border border-border/60 p-4 bg-card">
          <p className="text-sm text-foreground">系统设置内容区域。</p>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function ComponentsSection() {
  const btn = DESIGN_TOKENS.components.button;
  const input = DESIGN_TOKENS.components.input;
  const card = DESIGN_TOKENS.components.card;
  const tag = DESIGN_TOKENS.components.tag;
  const table = DESIGN_TOKENS.components.table;
  const sidebar = DESIGN_TOKENS.components.sidebar;
  const navbar = DESIGN_TOKENS.components.navbar;
  const tabs = DESIGN_TOKENS.components.tabs;

  const components = [
    {
      id: 'comp-button',
      title: '按钮 Button',
      description: '用于触发操作的基础组件，支持多种类型、尺寸和状态。',
      demo: <ButtonDemo />,
      specs: [
        { token: 'height.sm', value: btn.height.sm },
        { token: 'height.md', value: btn.height.md },
        { token: 'height.lg', value: btn.height.lg },
        { token: 'padding.sm', value: btn.padding.sm },
        { token: 'padding.md', value: btn.padding.md },
        { token: 'borderRadius', value: btn.borderRadius },
        { token: 'fontSize.md', value: btn.fontSize.md },
      ],
    },
    {
      id: 'comp-input',
      title: '输入框 Input',
      description: '用户输入文本的表单控件，支持多种状态和图标组合。',
      demo: <InputDemo />,
      specs: [
        { token: 'height.sm', value: input.height.sm },
        { token: 'height.md', value: input.height.md },
        { token: 'height.lg', value: input.height.lg },
        { token: 'paddingX', value: input.padding },
        { token: 'borderRadius', value: input.borderRadius },
      ],
    },
    {
      id: 'comp-card',
      title: '卡片 Card',
      description: '用于组织和展示相关内容的容器组件。',
      demo: <CardDemo />,
      specs: [
        { token: 'padding', value: card.padding },
        { token: 'borderRadius', value: card.borderRadius },
        { token: 'shadow', value: 'sm' },
      ],
    },
    {
      id: 'comp-tag',
      title: '标签 Tag',
      description: '用于标记、分类和强调信息的小型组件。',
      demo: <TagDemo />,
      specs: [
        { token: 'height', value: tag.height },
        { token: 'paddingX', value: tag.padding },
        { token: 'borderRadius', value: tag.borderRadius },
        { token: 'fontSize', value: tag.fontSize },
      ],
    },
    {
      id: 'comp-table',
      title: '表格 Table',
      description: '用于展示结构化数据的行列组件，支持排序、选择等操作。',
      demo: <TableDemo />,
      specs: [
        { token: 'rowHeight', value: table.rowHeight },
        { token: 'headerBg', value: table.headerBg },
        { token: 'borderRadius', value: table.borderRadius },
      ],
    },
    {
      id: 'comp-sidebar',
      title: '侧边栏 Sidebar',
      description: '页面级导航组件，提供菜单项的组织与快速访问。',
      demo: <SidebarDemo />,
      specs: [
        { token: 'width', value: sidebar.width },
        { token: 'collapsedWidth', value: sidebar.collapsedWidth },
        { token: 'itemHeight', value: sidebar.itemHeight },
        { token: 'background', value: sidebar.bg },
      ],
    },
    {
      id: 'comp-navbar',
      title: '导航栏 Navbar',
      description: '顶部导航组件，承载品牌标识、全局导航和用户操作。',
      demo: <NavbarDemo />,
      specs: [
        { token: 'height', value: navbar.height },
        { token: 'background', value: navbar.bg },
        { token: 'shadow', value: 'xs' },
      ],
    },
    {
      id: 'comp-tabs',
      title: '标签页 Tabs',
      description: '在同一区域内组织和切换不同内容视图的组件。',
      demo: <TabsDemo />,
      specs: [
        { token: 'itemHeight', value: tabs.itemHeight },
        { token: 'indicatorHeight', value: tabs.indicatorHeight },
        { token: 'fontSize', value: tabs.fontSize },
      ],
    },
  ];

  return (
    <section id="components" className="w-full border-t border-border/50 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Components"
          title="组件规范"
          description="可复用的 UI 组件库，每个组件都包含样式预览和规格参数，确保开发实现的一致性。"
        />

        <div className="mt-12 space-y-8">
          {components.map((comp, i) => (
            <motion.div
              key={comp.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.5, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
            >
              <ComponentBlock
                id={comp.id}
                title={comp.title}
                description={comp.description}
                specs={comp.specs}
              >
                {comp.demo}
              </ComponentBlock>
            </motion.div>
          ))}
        </div>

        <MoreComponentsSection />
      </div>
    </section>
  );
}
