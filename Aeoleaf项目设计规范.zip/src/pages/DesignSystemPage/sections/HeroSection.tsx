import { motion } from 'framer-motion';
import { ArrowDown, Download, Figma, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UniversalLink } from '@lark-apaas/client-toolkit-lite';

export default function HeroSection() {
  return (
    <section id="hero" className="relative overflow-hidden border-b border-border/50 bg-muted/30">
      <div className="relative mx-auto max-w-5xl px-4 py-16 md:px-6 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="space-y-6"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-foreground/20 bg-foreground/5 px-3 py-1 text-xs font-medium text-foreground">
            <span className="size-1.5 rounded-full bg-foreground" />
            v1.0.0 · 2024 发布
          </div>

          <h1 className="text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl">
            博客后台
            <span className="text-foreground">设计系统</span>
          </h1>

          <p className="max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
            一套面向博客后台管理系统的完整设计规范。基于黑白灰极简风格，
            覆盖色彩、排版、间距、组件、布局、交互等全链路设计语言，
            帮助团队快速构建一致、高效、克制的后台产品界面。
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button size="lg" className="gap-2">
              <Figma className="size-4" />
              Figma 设计稿
            </Button>
            <Button size="lg" variant="secondary" className="gap-2">
              <Code className="size-4" />
              组件库文档
            </Button>
            <Button size="lg" variant="outline" className="gap-2">
              <Download className="size-4" />
              下载 Token
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-8 sm:grid-cols-4">
            {[
              { label: '设计 Token', value: '120+' },
              { label: '组件数量', value: '30+' },
              { label: '布局模式', value: '6 种' },
              { label: '主题支持', value: '单色' },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="rounded-lg border border-border/50 bg-card/60 p-4"
              >
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="mt-1 text-xs text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="absolute bottom-6 left-1/2 -translate-x-1/2 text-muted-foreground"
        >
          <UniversalLink to="#principles" className="flex flex-col items-center gap-1 text-xs">
            <span>向下滚动</span>
            <ArrowDown className="size-4 animate-bounce" />
          </UniversalLink>
        </motion.div>
      </div>
    </section>
  );
}
