import { motion } from 'framer-motion';
import { Sparkles, Eye, Layers, ShieldCheck } from 'lucide-react';
import SectionHeading from './SectionHeading';

const PRINCIPLES = [
  {
    icon: Sparkles,
    title: '简约高效',
    description: '以内容为核心，去除不必要的视觉干扰，让用户专注于任务本身。界面层次清晰，信息密度适中，操作路径最短化。',
  },
  {
    icon: Eye,
    title: '一致性',
    description: '统一的视觉语言与交互模式贯穿整个系统。相同的元素在不同场景中保持一致的外观与行为，降低用户学习成本。',
  },
  {
    icon: Layers,
    title: '模块化',
    description: '采用组件化设计思想，所有 UI 元素均可复用与组合。通过基础组件的灵活搭配，快速构建复杂页面与功能。',
  },
  {
    icon: ShieldCheck,
    title: '可访问性',
    description: '遵循 WCAG 2.1 AA 级标准，确保色觉对比、键盘导航、语义化结构等可访问性要求，让所有用户都能顺畅使用。',
  },
];

export default function PrinciplesSection() {
  return (
    <section id="principles" className="w-full py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Foundations"
          title="设计原则"
          description="设计系统的核心理念与指导思想，所有设计决策都围绕这些原则展开。"
        />

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {PRINCIPLES.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="group rounded-xl border border-border/60 bg-card p-6 transition-all hover:border-foreground/30 hover:shadow-md"
              >
                <div className="mb-4 inline-flex size-11 items-center justify-center rounded-lg bg-foreground text-background">
                  <Icon className="size-5" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
