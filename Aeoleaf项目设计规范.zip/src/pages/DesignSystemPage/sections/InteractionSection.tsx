import { useState } from 'react';
import { motion } from 'framer-motion';
import { MousePointer2, Zap, MessageSquare, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

const STATES = [
  { name: '默认 Default', desc: '组件的基础状态，无任何交互。' },
  { name: '悬停 Hover', desc: '鼠标悬停时的视觉反馈，通常为轻微上浮或底色变化。' },
  { name: '激活 Active', desc: '点击瞬间的视觉反馈，按下状态。' },
  { name: '聚焦 Focus', desc: '键盘导航时的焦点状态，显示 focus ring。' },
  { name: '禁用 Disabled', desc: '不可交互状态，降低不透明度，禁用指针事件。' },
  { name: '加载 Loading', desc: '异步操作进行中，显示加载指示器。' },
];

const MOTION_TOKENS = [
  { token: 'fast', duration: '150ms', usage: '微交互（如按钮按下、开关切换）' },
  { token: 'base', duration: '250ms', usage: '标准过渡（如面板展开、颜色变化）' },
  { token: 'slow', duration: '400ms', usage: '较大变化（如页面切换、弹框出现）' },
];

function StateDemoButtons() {
  const [loading, setLoading] = useState(false);

  return (
    <div className="flex flex-wrap items-center gap-3">
      <Button>默认</Button>
      <Button variant="outline">描边默认</Button>
      <Button disabled>禁用</Button>
      <Button
        onClick={() => {
          setLoading(true);
          setTimeout(() => setLoading(false), 1500);
        }}
        disabled={loading}
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 size-4 animate-spin" />
            加载中
          </>
        ) : (
          '点击加载'
        )}
      </Button>
    </div>
  );
}

export default function InteractionSection() {
  return (
    <section id="interaction" className="w-full border-t border-border/50 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Interaction"
          title="交互规范"
          description="统一的交互反馈与动效规范，让用户的每一次操作都能获得清晰、及时的响应。"
        />

        {/* 状态反馈 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">状态反馈 · States</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            所有可交互组件都应具备完整的状态反馈，帮助用户理解当前界面状态与操作结果。
          </p>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {STATES.map((state, i) => (
              <motion.div
                key={state.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.4, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                className="rounded-xl border border-border/60 bg-card p-5"
              >
                <div className="mb-2 flex items-center gap-2">
                  <MousePointer2 className="size-4 text-foreground" />
                  <span className="text-sm font-semibold text-foreground">{state.name}</span>
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">{state.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-8 rounded-xl border border-border/60 bg-card p-6">
            <div className="mb-3 text-sm font-medium text-foreground">按钮状态演示</div>
            <StateDemoButtons />
          </div>
        </div>

        {/* 动效规范 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">动效规范 · Motion</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            动效应简洁自然，为交互提供流畅的视觉引导，而非分散用户注意力。
          </p>

          <div className="grid gap-6 md:grid-cols-2">
            {/* 过渡时长 */}
            <div className="rounded-xl border border-border/60 bg-card p-6">
              <div className="mb-4 flex items-center gap-2">
                <Zap className="size-4 text-foreground" />
                <span className="text-sm font-semibold text-foreground">过渡时长 Duration</span>
              </div>
              <div className="space-y-3">
                {MOTION_TOKENS.map((t) => (
                  <div key={t.token} className="flex items-center gap-3">
                    <div className="w-20 shrink-0">
                      <div className="text-xs font-medium text-foreground">{t.token}</div>
                      <div className="font-mono text-[10px] text-muted-foreground">{t.duration}</div>
                    </div>
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: t.duration === '150ms' ? '60px' : t.duration === '250ms' ? '100px' : '160px' }}
                      viewport={{ once: true }}
                      transition={{ duration: Number(t.duration.replace('ms', '')) / 1000 + 0.2, ease: 'easeOut' }}
                      className="h-2 rounded-full bg-foreground/80"
                    />
                    <div className="flex-1 text-xs text-muted-foreground">{t.usage}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* 缓动函数 */}
            <div className="rounded-xl border border-border/60 bg-card p-6">
              <div className="mb-4 flex items-center gap-2">
                <MessageSquare className="size-4 text-foreground" />
                <span className="text-sm font-semibold text-foreground">缓动函数 Easing</span>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="font-mono text-xs text-foreground">
                    {DESIGN_TOKENS.motion.easing}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    标准缓动（ease-in-out），适用于大多数过渡动画。
                  </div>
                </div>
                {/* 简易贝塞尔曲线示意 */}
                <div className="relative h-24 rounded-lg bg-muted/40 p-3">
                  <svg viewBox="0 0 100 60" className="h-full w-full">
                    <line x1="0" y1="60" x2="100" y2="0" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 2" className="text-border" />
                    <path
                      d="M 0 60 C 40 60, 20 0, 100 0"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-foreground"
                    />
                    <circle cx="0" cy="60" r="2.5" className="fill-foreground" />
                    <circle cx="100" cy="0" r="2.5" className="fill-foreground" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 反馈模式 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">操作反馈 · Feedback</h3>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { title: '即时反馈', desc: '按钮点击、输入框聚焦等微操作应在 100ms 内给出视觉响应。' },
              { title: '过程反馈', desc: '需要等待的操作（如提交、加载）应显示加载状态，避免用户重复操作。' },
              { title: '结果反馈', desc: '操作完成后通过 Toast、弹窗或状态变化告知用户成功或失败。' },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="rounded-xl border border-border/60 bg-card p-5"
              >
                <div className="text-sm font-semibold text-foreground">{item.title}</div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
