import { motion } from 'framer-motion';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

const SPACING_ITEMS = Object.entries(DESIGN_TOKENS.spacing);
const RADIUS_ITEMS = Object.entries(DESIGN_TOKENS.radius);
const SHADOW_ITEMS = Object.entries(DESIGN_TOKENS.shadow);

export default function SpacingSection() {
  return (
    <section id="spacing" className="w-full border-t border-border/50 bg-muted/20 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Spacing & Grid"
          title="间距与栅格"
          description="基于 4px 基准的间距刻度体系，配合 12 列栅格与统一的圆角阴影，确保视觉节奏的一致性。"
        />

        {/* 间距刻度 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">间距刻度 · Spacing Scale</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            以 4px 为基础单位，通过倍增方式生成间距刻度，确保空间节奏的一致性。
          </p>
          <div className="space-y-3 rounded-xl border border-border/60 bg-card p-6">
            {SPACING_ITEMS.filter(([key]) => key !== '0').map(([key, value], i) => (
              <motion.div
                key={key}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.3, delay: i * 0.03, ease: [0.16, 1, 0.3, 1] }}
                className="flex items-center gap-4"
              >
                <div className="w-20 shrink-0 text-xs font-medium text-muted-foreground">
                  {key}
                </div>
                <div
                  className="h-4 rounded bg-foreground/70"
                  style={{ width: value, minWidth: '8px', maxWidth: '200px' }}
                />
                <div className="font-mono text-xs text-muted-foreground">{value}</div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* 圆角 & 阴影 */}
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {/* 圆角 */}
          <div>
            <h3 className="mb-4 text-base font-semibold text-foreground">圆角 · Border Radius</h3>
            <div className="grid grid-cols-3 gap-3 rounded-xl border border-border/60 bg-card p-5">
              {RADIUS_ITEMS.filter(([k]) => k !== 'none').map(([key, value]) => (
                <div key={key} className="flex flex-col items-center gap-2">
                  <div
                    className="size-14 bg-foreground/80"
                    style={{ borderRadius: value }}
                  />
                  <div className="text-[11px] font-medium text-foreground">{key}</div>
                  <div className="text-[10px] font-mono text-muted-foreground">{value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* 阴影 */}
          <div>
            <h3 className="mb-4 text-base font-semibold text-foreground">阴影 · Shadow</h3>
            <div className="grid grid-cols-3 gap-3 rounded-xl border border-border/60 bg-card p-5">
              {SHADOW_ITEMS.filter(([k]) => k !== 'none').map(([key, value]) => (
                <div key={key} className="flex flex-col items-center gap-2">
                  <div
                    className="size-14 rounded-lg bg-background"
                    style={{ boxShadow: value }}
                  />
                  <div className="text-[11px] font-medium text-foreground">{key}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 栅格系统 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">栅格系统 · Grid System</h3>
          <div className="rounded-xl border border-border/60 bg-card p-6">
            <div className="mb-4 grid grid-cols-12 gap-2">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="h-20 rounded bg-foreground/10"
                />
              ))}
            </div>
            <div className="grid gap-4 text-sm sm:grid-cols-4">
              <div>
                <div className="text-xs text-muted-foreground">列数</div>
                <div className="mt-1 font-medium text-foreground">{DESIGN_TOKENS.grid.columns} 列</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">列间距 Gutter</div>
                <div className="mt-1 font-medium text-foreground">{DESIGN_TOKENS.grid.gutter}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">页边距 Margin</div>
                <div className="mt-1 font-medium text-foreground">{DESIGN_TOKENS.grid.margin}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">最大宽度</div>
                <div className="mt-1 font-medium text-foreground">{DESIGN_TOKENS.grid.maxWidth}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
