import { motion } from 'framer-motion';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

const TYPOGRAPHY_SCALE = [
  { token: 'display-1', label: 'Display 1', size: '42px', weight: 700, tag: '特大标题' },
  { token: 'display-2', label: 'Display 2', size: '34px', weight: 700, tag: '大标题' },
  { token: 'h1', label: 'H1 / Heading 1', size: '30px', weight: 600, tag: '一级标题' },
  { token: 'h2', label: 'H2 / Heading 2', size: '24px', weight: 600, tag: '二级标题' },
  { token: 'h3', label: 'H3 / Heading 3', size: '20px', weight: 600, tag: '三级标题' },
  { token: 'h4', label: 'H4 / Heading 4', size: '18px', weight: 500, tag: '四级标题' },
  { token: 'h5', label: 'H5 / Heading 5', size: '16px', weight: 500, tag: '五级标题' },
  { token: 'h6', label: 'H6 / Heading 6', size: '14px', weight: 500, tag: '六级标题' },
  { token: 'body-lg', label: 'Body Large', size: '16px', weight: 400, tag: '大正文' },
  { token: 'body', label: 'Body / Base', size: '14px', weight: 400, tag: '正文字' },
  { token: 'body-sm', label: 'Body Small', size: '13px', weight: 400, tag: '小正文' },
  { token: 'caption', label: 'Caption', size: '12px', weight: 400, tag: '辅助文字' },
];

export default function TypographySection() {
  return (
    <section id="typography" className="w-full py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Typography"
          title="排版系统"
          description="清晰的字体层级与规范的行高字重，确保信息传达的效率与阅读舒适度。"
        />

        {/* 字体族 */}
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-xl border border-border/60 bg-card p-6"
          >
            <div className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              中文字体 / Sans-serif
            </div>
            <div className="text-4xl font-semibold text-foreground" style={{ fontFamily: DESIGN_TOKENS.typography.fontFamily.sans }}>
              博客后台管理
            </div>
            <div className="mt-4 text-sm text-muted-foreground">
              {DESIGN_TOKENS.typography.fontFamily.sans}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-xl border border-border/60 bg-card p-6"
          >
            <div className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              等宽字体 / Monospace
            </div>
            <div className="text-4xl font-semibold text-foreground" style={{ fontFamily: DESIGN_TOKENS.typography.fontFamily.mono }}>
              Code 0123
            </div>
            <div className="mt-4 text-sm text-muted-foreground" style={{ fontFamily: DESIGN_TOKENS.typography.fontFamily.mono }}>
              {DESIGN_TOKENS.typography.fontFamily.mono}
            </div>
          </motion.div>
        </div>

        {/* 字号层级 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">字号层级 · Type Scale</h3>
          <div className="overflow-hidden rounded-xl border border-border/60 bg-card">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/60 bg-muted/30">
                  <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">预览</th>
                  <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Token</th>
                  <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">字号</th>
                  <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">字重</th>
                </tr>
              </thead>
              <tbody>
                {TYPOGRAPHY_SCALE.map((item, i) => (
                  <tr key={item.token} className="border-b border-border/40 last:border-b-0 hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <span
                        style={{ fontSize: item.size, fontWeight: item.weight, lineHeight: 1.3 }}
                        className="text-foreground"
                      >
                        博客 Admin Blog
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-sm font-medium text-foreground">{item.label}</div>
                      <div className="text-xs text-muted-foreground">{item.tag}</div>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{item.size}</td>
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{item.weight}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
