import { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check } from 'lucide-react';
import { toast } from 'sonner';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

function ColorSwatch({ name, value, dark }: { name: string; value: string; dark?: boolean }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast.success(`已复制 ${value}`);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      toast.error('复制失败');
    }
  };

  return (
    <motion.button
      whileHover={{ y: -2, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleCopy}
      className="group relative flex flex-col overflow-hidden rounded-lg border border-border/60 text-left transition-shadow hover:shadow-md"
    >
      <div
        className="h-16 w-full"
        style={{ backgroundColor: value }}
      />
      <div className="flex items-center justify-between gap-2 p-3 bg-card">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">
            {name}
          </div>
          <div className="text-[11px] text-muted-foreground font-mono">{value}</div>
        </div>
        {copied ? (
          <Check className="size-3.5 text-foreground shrink-0" />
        ) : (
          <Copy className="size-3.5 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 shrink-0" />
        )}
      </div>
    </motion.button>
  );
}

function SemanticSwatch({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border/60 p-3">
      <div
        className="size-10 shrink-0 rounded-md"
        style={{ backgroundColor: value }}
      />
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium text-foreground">{label}</div>
        <div className="text-xs font-mono text-muted-foreground">{value}</div>
      </div>
    </div>
  );
}

export default function ColorsSection() {
  const primary = Object.entries(DESIGN_TOKENS.colors.primary);
  const secondary = Object.entries(DESIGN_TOKENS.colors.secondary);
  const neutral = Object.entries(DESIGN_TOKENS.colors.neutral);
  const semantic = DESIGN_TOKENS.colors.semantic;

  return (
    <section id="colors" className="w-full border-t border-border/50 bg-muted/20 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Color System"
          title="色彩系统"
          description="黑白灰色阶体系，通过明度对比构建清晰的视觉层次。点击色块可复制色值。"
        />

        {/* 主色 */}
        <div id="colors-primary" className="mt-12 scroll-mt-20">
          <h3 className="mb-4 text-base font-semibold text-foreground">主色阶 · Primary Scale</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            用于主按钮、关键操作、文字标题等核心视觉元素，通过明度变化表达层级关系。
          </p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {primary.map(([key, value]) => (
              <ColorSwatch key={key} name={`gray-${key}`} value={value} dark={Number(key) >= 600} />
            ))}
          </div>
        </div>

        {/* 辅色阶 */}
        <div className="mt-10">
          <h3 className="mb-4 text-base font-semibold text-foreground">辅色阶 · Secondary Scale</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            辅助灰阶，用于次按钮、边框、背景等元素，与主色阶形成细腻的层次过渡。
          </p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {secondary.map(([key, value]) => (
              <ColorSwatch key={key} name={`stone-${key}`} value={value} dark={Number(key) >= 600} />
            ))}
          </div>
        </div>

        {/* 中性色 */}
        <div id="colors-neutral" className="mt-10 scroll-mt-20">
          <h3 className="mb-4 text-base font-semibold text-foreground">中性色 · Neutral</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            用于背景、文字、边框等基础视觉层次，支撑整个界面的可读性。
          </p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {neutral.map(([key, value]) => (
              <ColorSwatch key={key} name={`neutral-${key}`} value={value} dark={Number(key) >= 600} />
            ))}
          </div>
        </div>

        {/* 语义色 */}
        <div id="colors-semantic" className="mt-10 scroll-mt-20">
          <h3 className="mb-4 text-base font-semibold text-foreground">语义色 · Semantic</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            单色主题下，语义色通过不同明度灰阶表达功能权重，配合图标与文字传达状态含义。
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <SemanticSwatch label="强调 Emphasis" value={semantic.success} />
            <SemanticSwatch label="次级 Secondary" value={semantic.info} />
            <SemanticSwatch label="弱提示 Muted" value={semantic.warning} />
            <SemanticSwatch label="最强 Strong" value={semantic.error} />
          </div>
        </div>
      </div>
    </section>
  );
}
