import { motion } from 'framer-motion';
import { Moon, Contrast, Layers, CheckCircle, Eye, Zap } from 'lucide-react';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

function DarkSwatch({ name, value, style }: { name: string; value: string; style?: React.CSSProperties }) {
  return (
    <div className="flex flex-col overflow-hidden rounded-lg border border-foreground/10">
      <div className="h-14 w-full" style={{ backgroundColor: value, ...style }} />
      <div className="flex items-center justify-between gap-2 p-2.5 bg-card">
        <div className="text-[11px] font-medium text-foreground">{name}</div>
        <div className="text-[10px] font-mono text-muted-foreground">{value}</div>
      </div>
    </div>
  );
}

function PrincipleCard({ icon: Icon, title, desc }: { icon: React.ComponentType<{ className?: string }>; title: string; desc: string }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card p-5">
      <div className="mb-3 inline-flex size-10 items-center justify-center rounded-lg bg-foreground/10 text-foreground">
        <Icon className="size-5" />
      </div>
      <h4 className="text-sm font-semibold text-foreground">{title}</h4>
      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{desc}</p>
    </div>
  );
}

export default function DarkModeSection() {
  const dark = DESIGN_TOKENS.colors.dark;

  return (
    <section id="dark-mode" className="w-full border-t border-border/50 py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <SectionHeading
          eyebrow="Dark Mode"
          title="深色模式规范"
          description="在低光环境下保护视力的深色配色方案，与浅色模式共享同一套设计语言，通过灰度层级构建清晰的视觉层次。"
        />

        {/* 设计原则 */}
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: Contrast, title: '对比度优先', desc: '正文与背景对比度不低于 7:1，辅助文字不低于 4.5:1，确保可读性与可访问性。' },
            { icon: Layers, title: '背景层级化', desc: '通过不同明度的深灰区分页面、卡片、弹层的层级关系，越深的颜色代表越高的层级。' },
            { icon: Eye, title: '降低眩光', desc: '避免纯黑（#000000）背景，采用深灰底色减少瞳孔剧烈收缩带来的视觉疲劳。' },
            { icon: CheckCircle, title: '状态一致性', desc: '组件状态逻辑与浅色模式保持一致，仅调整色彩明度，不改变交互模式与信息层级。' },
            { icon: Zap, title: '平滑过渡', desc: '深浅模式切换时，背景、边框、文字颜色以 250ms 缓动过渡，避免突兀闪烁。' },
            { icon: Moon, title: '灰度表达', desc: '延续单色设计语言，所有语义色通过不同明度的灰阶表达，保持整体风格统一。' },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              <PrincipleCard icon={item.icon} title={item.title} desc={item.desc} />
            </motion.div>
          ))}
        </div>

        {/* 背景层级 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">背景层级 · Background Layers</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            深色模式通过背景色的明度差异表达层级关系：页面底色最深，卡片次之，悬浮层与弹层最亮。
          </p>
          <div className="grid gap-4 sm:grid-cols-3">
            <DarkSwatch name="页面背景 Background" value={dark.background} />
            <DarkSwatch name="卡片背景 Card" value={dark.card} />
            <DarkSwatch name="悬浮/弹层 Popover" value={dark.popover} />
          </div>
          {/* 层级嵌套示意图 */}
          <div className="mt-6 flex items-end justify-center gap-6 rounded-xl border border-border/60 bg-card p-8">
            <div className="text-center">
              <div className="flex size-40 items-center justify-center rounded-lg" style={{ backgroundColor: dark.background }}>
                <div className="size-28 rounded-md flex items-center justify-center" style={{ backgroundColor: dark.card }}>
                  <div className="size-16 rounded" style={{ backgroundColor: dark.popover }} />
                </div>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">层级嵌套示意</div>
            </div>
          </div>
        </div>

        {/* 文字层级 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">文字层级 · Text Hierarchy</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            深色模式下文字同样采用四级明度区分信息权重，保证阅读舒适度与信息清晰度。
          </p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { label: '一级文字（标题/正文）', value: dark.foreground, weight: 'font-semibold', size: 'text-base' },
              { label: '二级文字（辅助信息）', value: dark.mutedForeground, weight: 'font-normal', size: 'text-sm' },
              { label: '三级文字（次要说明）', value: '#737373', weight: 'font-normal', size: 'text-xs' },
              { label: '禁用文字', value: dark.disabledForeground, weight: 'font-normal', size: 'text-xs' },
            ].map((t, i) => (
              <motion.div
                key={t.label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="rounded-lg border border-border/60 bg-card p-4"
              >
                <div className={`${t.weight} ${t.size}`} style={{ color: t.value }}>
                  文字样例 Aa
                </div>
                <div className="mt-3 text-xs text-muted-foreground">{t.label}</div>
                <div className="font-mono text-[11px] text-muted-foreground/70">{t.value}</div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* 边框与分割线 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">边框与分割线 · Border & Divider</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-lg border border-border/60 bg-card p-5">
              <div className="text-sm font-medium text-foreground">组件边框 Border</div>
              <div className="mt-2 flex items-center gap-3">
                <div className="size-10 rounded border" style={{ borderColor: dark.border, backgroundColor: 'transparent' }} />
                <div>
                  <div className="font-mono text-xs text-foreground">{dark.border}</div>
                  <div className="text-[11px] text-muted-foreground">用于输入框、按钮、卡片等组件边界</div>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-border/60 bg-card p-5">
              <div className="text-sm font-medium text-foreground">分割线 Divider</div>
              <div className="mt-2 flex flex-col gap-3">
                <div className="h-px w-full" style={{ backgroundColor: dark.divider }} />
                <div>
                  <div className="font-mono text-xs text-foreground">{dark.divider}</div>
                  <div className="text-[11px] text-muted-foreground">用于列表分隔、内容区块之间的弱分割</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 语义色 */}
        <div className="mt-12">
          <h3 className="mb-4 text-base font-semibold text-foreground">语义色 · Semantic（深色模式）</h3>
          <p className="mb-6 text-sm text-muted-foreground">
            深色模式下，语义色同样通过灰度表达。颜色越深表示权重越弱，越接近白色表示强调程度越高。
          </p>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { label: '强调 Strong', value: dark.semantic.strong, desc: '最强烈的视觉信号' },
              { label: '重要 Emphasis', value: dark.semantic.emphasis, desc: '主要操作与信息' },
              { label: '次级 Secondary', value: dark.semantic.secondary, desc: '次要提示信息' },
              { label: '弱化 Muted', value: dark.semantic.muted, desc: '辅助、低优先级' },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-3 rounded-lg border border-border/60 p-3">
                <div className="size-10 shrink-0 rounded-md" style={{ backgroundColor: s.value }} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium text-foreground">{s.label}</div>
                  <div className="text-[11px] text-muted-foreground">{s.desc}</div>
                  <div className="font-mono text-[11px] text-muted-foreground/70">{s.value}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 对比度说明 */}
        <div className="mt-12 rounded-xl border border-border/60 bg-card p-6">
          <h3 className="mb-3 text-base font-semibold text-foreground">对比度要求</h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            <p>深色模式下必须严格保证文字与背景的对比度，满足 WCAG 2.1 AA 级标准：</p>
            <ul className="list-disc space-y-1.5 pl-5 text-xs">
              <li>正文文本与背景对比度 ≥ 4.5:1（AA 级）</li>
              <li>大字号（18pt 加粗或 24pt 常规）对比度 ≥ 3:1</li>
              <li>图标与功能图形对比度 ≥ 3:1</li>
              <li>禁用状态文字对比度无强制要求，但建议 ≥ 2:1 以保持可识别性</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
