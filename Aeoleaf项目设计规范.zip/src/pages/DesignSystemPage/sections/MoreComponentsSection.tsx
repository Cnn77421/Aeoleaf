import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  X,
  Settings,
  User,
  Bell,
  LogOut,
  FileText,
  FolderOpen,
  Check,
  Minus,
  Inbox,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from '@/components/ui/dropdown-menu';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import { Skeleton } from '@/components/ui/skeleton';
import { DESIGN_TOKENS } from '@/data/design-tokens';
import SectionHeading from './SectionHeading';

function SpecTable({ rows }: { rows: { token: string; value: string }[] }) {
  return (
    <div className="overflow-hidden rounded-lg border border-border/60">
      <table className="w-full text-sm">
        <thead className="bg-muted/40">
          <tr>
            <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">Token</th>
            <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">Value</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.token} className="border-t border-border/40">
              <td className="px-3 py-2 font-mono text-xs text-foreground">{r.token}</td>
              <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{r.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ComponentBlock({ id, title, description, children, specs }: {
  id: string;
  title: string;
  description: string;
  children: React.ReactNode;
  specs: { token: string; value: string }[];
}) {
  return (
    <div id={id} className="scroll-mt-20 rounded-xl border border-border/60 bg-card overflow-hidden">
      <div className="border-b border-border/60 p-5">
        <h4 className="text-base font-semibold text-foreground">{title}</h4>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
      <div className="flex flex-col lg:flex-row">
        <div className="flex-1 p-6 bg-muted/20 flex items-center justify-center min-h-[200px]">
          {children}
        </div>
        <div className="w-full border-t border-border/60 p-4 lg:w-64 lg:border-l lg:border-t-0 lg:p-5">
          <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">规格</div>
          <SpecTable rows={specs} />
        </div>
      </div>
    </div>
  );
}

/* ============ 下拉菜单 ============ */
function DropdownDemo() {
  return (
    <div className="flex flex-wrap items-center gap-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="gap-1">
            操作
            <ChevronDown className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-48" align="start">
          <DropdownMenuLabel>我的账户</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <User className="mr-2 size-4" />
            个人资料
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Settings className="mr-2 size-4" />
            系统设置
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem disabled>
            <Bell className="mr-2 size-4" />
            消息通知（禁用）
          </DropdownMenuItem>
          <DropdownMenuItem className="text-destructive focus:text-destructive">
            <LogOut className="mr-2 size-4" />
            退出登录
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="gap-1">
            多选菜单
            <ChevronDown className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-48" align="start">
          <DropdownMenuLabel>显示列</DropdownMenuLabel>
          <DropdownMenuCheckboxItem checked>标题</DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked>作者</DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem>发布时间</DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem>浏览量</DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

/* ============ 弹窗 ============ */
function ModalDemo() {
  const [size, setSize] = useState<'sm' | 'md' | 'lg'>('md');
  const sizeMap = { sm: 'sm', md: 'default', lg: 'lg' } as const;

  return (
    <div className="w-full max-w-md space-y-4">
      <div className="flex items-center justify-center gap-2">
        <Button
          variant={size === 'sm' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSize('sm')}
        >
          小
        </Button>
        <Button
          variant={size === 'md' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSize('md')}
        >
          中
        </Button>
        <Button
          variant={size === 'lg' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSize('lg')}
        >
          大
        </Button>
      </div>
      <Dialog>
        <DialogTrigger asChild>
          <Button className="mx-auto block">打开弹窗</Button>
        </DialogTrigger>
        <DialogContent className={size === 'sm' ? 'sm:max-w-sm' : size === 'lg' ? 'sm:max-w-3xl' : 'sm:max-w-lg'}>
          <DialogHeader>
            <DialogTitle>
              {size === 'sm' ? '提示' : size === 'md' ? '编辑文章' : '文章详情'}
            </DialogTitle>
            <DialogDescription>
              {size === 'sm'
                ? '确认执行此操作吗？此操作不可撤销。'
                : size === 'md'
                ? '修改文章的基本信息，修改后将实时保存。'
                : '查看文章的完整信息，包括内容、统计数据和操作记录。'}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {size === 'sm' ? (
              <p className="text-sm text-muted-foreground">
                删除后数据将无法恢复，请谨慎操作。
              </p>
            ) : (
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">文章标题</Label>
                  <Input defaultValue="React 19 新特性解析" className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">分类</Label>
                  <Input defaultValue="前端开发" className="mt-1" />
                </div>
                {size === 'lg' && (
                  <div>
                    <Label className="text-xs text-muted-foreground">摘要</Label>
                    <Input defaultValue="深入解析 React 19 的新特性，包括 Server Components、Actions 等..." className="mt-1" />
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">取消</Button>
            </DialogClose>
            <Button>
              {size === 'sm' ? '确认删除' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ============ 分页 ============ */
function PaginationDemo() {
  return (
    <div className="w-full max-w-2xl space-y-6">
      <div>
        <div className="mb-2 text-xs text-muted-foreground">基础分页</div>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious href="#" />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">1</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#" isActive>2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">3</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">4</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">5</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationNext href="#" />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>

      <div>
        <div className="mb-2 text-xs text-muted-foreground">带省略号的分页</div>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious href="#" />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">1</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationEllipsis />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#" isActive>8</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">9</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationNext href="#" />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>

      <div className="flex items-center justify-between gap-4">
        <div className="text-xs text-muted-foreground">
          共 248 条，每页
          <select className="mx-1 rounded border border-border bg-background px-2 py-0.5 text-xs">
            <option>10</option>
            <option>20</option>
            <option>50</option>
          </select>
          条
        </div>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious href="#" />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#" isActive>1</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">3</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationNext href="#" />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          跳至
          <Input type="number" defaultValue={1} className="h-7 w-14 px-2 text-center" />
          页
        </div>
      </div>
    </div>
  );
}

/* ============ 面包屑 ============ */
function BreadcrumbDemo() {
  return (
    <div className="w-full max-w-md space-y-4">
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="#">首页</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="#">文章管理</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>文章详情</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="#">仪表盘</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
            <ChevronRight className="size-3" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbLink href="#">内容管理</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
            <ChevronRight className="size-3" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbLink href="#">分类</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
            <ChevronRight className="size-3" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbPage>技术</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
    </div>
  );
}

/* ============ 开关 ============ */
function SwitchDemo() {
  return (
    <div className="flex flex-wrap items-center gap-6">
      <div className="flex flex-col items-center gap-2">
        <Switch />
        <span className="text-xs text-muted-foreground">默认</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Switch defaultChecked />
        <span className="text-xs text-muted-foreground">开启</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Switch disabled />
        <span className="text-xs text-muted-foreground">禁用（关）</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Switch defaultChecked disabled />
        <span className="text-xs text-muted-foreground">禁用（开）</span>
      </div>
      <div className="flex items-center gap-2">
        <Switch id="switch-label" />
        <Label htmlFor="switch-label" className="text-sm">带标签的开关</Label>
      </div>
    </div>
  );
}

/* ============ 复选框 & 单选框 ============ */
function CheckboxRadioDemo() {
  return (
    <div className="w-full max-w-md grid grid-cols-2 gap-8">
      <div className="space-y-3">
        <div className="text-sm font-medium text-foreground mb-2">复选框 Checkbox</div>
        <div className="flex items-center space-x-2">
          <Checkbox id="c1" />
          <Label htmlFor="c1" className="text-sm">默认</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="c2" defaultChecked />
          <Label htmlFor="c2" className="text-sm">已选中</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="c3" checked="indeterminate" />
          <Label htmlFor="c3" className="text-sm">半选</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="c4" disabled />
          <Label htmlFor="c4" className="text-sm text-muted-foreground">禁用</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="c5" defaultChecked disabled />
          <Label htmlFor="c5" className="text-sm text-muted-foreground">禁用选中</Label>
        </div>
      </div>

      <div className="space-y-3">
        <div className="text-sm font-medium text-foreground mb-2">单选框 Radio</div>
        <div className="flex items-center space-x-2">
          <div className="size-4 rounded-full border border-border bg-background" />
          <Label className="text-sm">默认</Label>
        </div>
        <div className="flex items-center space-x-2">
          <div className="size-4 rounded-full border-2 border-foreground bg-background flex items-center justify-center">
            <div className="size-2 rounded-full bg-foreground" />
          </div>
          <Label className="text-sm">已选中</Label>
        </div>
        <div className="flex items-center space-x-2">
          <div className="size-4 rounded-full border border-border bg-muted/50" />
          <Label className="text-sm text-muted-foreground">禁用</Label>
        </div>
        <div className="flex items-center space-x-2">
          <div className="size-4 rounded-full border-2 border-muted bg-muted flex items-center justify-center">
            <div className="size-2 rounded-full bg-muted-foreground/40" />
          </div>
          <Label className="text-sm text-muted-foreground">禁用选中</Label>
        </div>
      </div>
    </div>
  );
}

/* ============ 提示气泡 ============ */
function TooltipDemo() {
  return (
    <TooltipProvider delayDuration={100}>
      <div className="grid grid-cols-3 gap-8 place-items-center">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="sm">上方</Button>
          </TooltipTrigger>
          <TooltipContent side="top">
            <p>顶部提示信息</p>
          </TooltipContent>
        </Tooltip>

        <div className="flex gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm">左侧</Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p>左侧提示</p>
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm">右侧</Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>右侧提示</p>
            </TooltipContent>
          </Tooltip>
        </div>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="sm">下方</Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>底部提示信息</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}

/* ============ 空状态 ============ */
function EmptyDemo() {
  return (
    <div className="w-full max-w-md space-y-6">
      <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border/60 bg-card p-8 text-center">
        <div className="flex size-20 items-center justify-center">
          <svg viewBox="0 0 100 100" className="size-full text-muted-foreground/30" fill="none" stroke="currentColor" strokeWidth="1.5">
            <rect x="20" y="15" width="60" height="70" rx="4" />
            <line x1="30" y1="30" x2="70" y2="30" />
            <line x1="30" y1="42" x2="60" y2="42" />
            <line x1="30" y1="54" x2="65" y2="54" />
            <line x1="30" y1="66" x2="50" y2="66" />
            <circle cx="60" cy="70" r="10" fill="none" />
          </svg>
        </div>
        <div className="text-sm font-medium text-foreground">暂无数据</div>
        <div className="text-xs text-muted-foreground">还没有任何内容，点击下方按钮添加第一条</div>
        <Button size="sm" className="mt-1">
          新建文章
        </Button>
      </div>
    </div>
  );
}

/* ============ 加载状态 ============ */
function LoadingDemo() {
  return (
    <div className="w-full max-w-md space-y-6">
      <div className="space-y-3">
        <div className="text-xs text-muted-foreground">骨架屏 Skeleton</div>
        <div className="space-y-3 rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center gap-3">
            <Skeleton className="size-10 rounded-full" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-3 w-32" />
            </div>
          </div>
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-3 w-4/5" />
          <Skeleton className="h-3 w-3/5" />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex flex-col items-center gap-2">
          <div className="size-6 animate-spin rounded-full border-2 border-border border-t-foreground" />
          <span className="text-xs text-muted-foreground">旋转加载</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="flex gap-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="size-1.5 rounded-full bg-foreground/40 animate-pulse"
                style={{ animationDelay: `${i * 150}ms` }}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">点状加载</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <Button disabled>
            <svg className="mr-2 size-4 animate-spin" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity="0.25" strokeWidth="4" />
              <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
            </svg>
            加载中
          </Button>
          <span className="text-xs text-muted-foreground">按钮加载</span>
        </div>
      </div>
    </div>
  );
}

/* ============ 通知徽标 ============ */
function BadgeNotificationDemo() {
  return (
    <div className="flex items-center gap-8">
      <div className="flex flex-col items-center gap-2">
        <div className="relative">
          <Bell className="size-6 text-foreground" />
          <span className="absolute -right-1 -top-1 flex min-w-[18px] items-center justify-center rounded-full bg-foreground px-1 text-[11px] font-medium text-background">
            5
          </span>
        </div>
        <span className="text-xs text-muted-foreground">数字徽标</span>
      </div>

      <div className="flex flex-col items-center gap-2">
        <div className="relative">
          <Inbox className="size-6 text-foreground" />
          <span className="absolute -right-0.5 -top-0.5 size-2 rounded-full bg-foreground" />
        </div>
        <span className="text-xs text-muted-foreground">红点徽标</span>
      </div>

      <div className="flex flex-col items-center gap-2">
        <div className="relative">
          <User className="size-6 text-foreground" />
          <span className="absolute -right-1 -top-1 flex min-w-[18px] items-center justify-center rounded-full bg-foreground px-1 text-[11px] font-medium text-background">
            99+
          </span>
        </div>
        <span className="text-xs text-muted-foreground">大数字徽标</span>
      </div>

      <div className="flex flex-col items-center gap-2">
        <div className="relative">
          <div className="size-9 rounded-full bg-muted flex items-center justify-center text-xs font-medium">A</div>
          <span className="absolute right-0 top-0 size-2.5 rounded-full bg-foreground ring-2 ring-background" />
        </div>
        <span className="text-xs text-muted-foreground">头像徽标</span>
      </div>
    </div>
  );
}

export default function MoreComponentsSection() {
  const dd = DESIGN_TOKENS.components.dropdown;
  const md = DESIGN_TOKENS.components.modal;
  const pg = DESIGN_TOKENS.components.pagination;
  const bc = DESIGN_TOKENS.components.breadcrumb;
  const sw = DESIGN_TOKENS.components.switch;
  const cb = DESIGN_TOKENS.components.checkbox;
  const tt = DESIGN_TOKENS.components.tooltip;
  const em = DESIGN_TOKENS.components.empty;
  const ld = DESIGN_TOKENS.components.loading;
  const bd = DESIGN_TOKENS.components.notificationBadge;

  const components = [
    {
      id: 'comp-dropdown',
      title: '下拉菜单 Dropdown',
      description: '点击触发后展开的菜单列表，支持分组、分割线、禁用态、多选等变体。',
      demo: <DropdownDemo />,
      specs: [
        { token: 'minWidth', value: dd.minWidth },
        { token: 'padding', value: dd.padding },
        { token: 'borderRadius', value: dd.borderRadius },
        { token: 'itemHeight', value: dd.itemHeight },
        { token: 'itemPadding', value: dd.itemPadding },
      ],
    },
    {
      id: 'comp-modal',
      title: '弹窗 Modal',
      description: '中断当前操作并聚焦于特定任务的浮层容器，支持小/中/大三种尺寸。',
      demo: <ModalDemo />,
      specs: [
        { token: 'size.sm', value: md.sizes.sm },
        { token: 'size.md', value: md.sizes.md },
        { token: 'size.lg', value: md.sizes.lg },
        { token: 'borderRadius', value: md.borderRadius },
        { token: 'padding', value: md.padding },
        { token: 'headerHeight', value: md.headerHeight },
      ],
    },
    {
      id: 'comp-pagination',
      title: '分页 Pagination',
      description: '将大量数据分割成多页展示的导航组件，支持页码、省略号、跳页等功能。',
      demo: <PaginationDemo />,
      specs: [
        { token: 'itemSize', value: pg.itemSize },
        { token: 'itemBorderRadius', value: pg.itemBorderRadius },
        { token: 'itemGap', value: pg.itemGap },
        { token: 'fontSize', value: pg.fontSize },
      ],
    },
    {
      id: 'comp-breadcrumb',
      title: '面包屑 Breadcrumb',
      description: '展示当前页面在层级结构中的位置，并支持向上层级导航。',
      demo: <BreadcrumbDemo />,
      specs: [
        { token: 'fontSize', value: bc.fontSize },
        { token: 'itemHeight', value: bc.itemHeight },
        { token: 'separatorGap', value: bc.separatorGap },
      ],
    },
    {
      id: 'comp-switch',
      title: '开关 Switch',
      description: '在两种状态之间切换的组件，常用于功能开关、设置项等场景。',
      demo: <SwitchDemo />,
      specs: [
        { token: 'width', value: sw.width },
        { token: 'height', value: sw.height },
        { token: 'thumbSize', value: sw.thumbSize },
        { token: 'borderRadius', value: sw.borderRadius },
        { token: 'transition', value: sw.transitionDuration },
      ],
    },
    {
      id: 'comp-checkbox-radio',
      title: '复选框 & 单选框 Checkbox & Radio',
      description: '表单选择控件，支持默认/选中/半选/禁用等多种状态。',
      demo: <CheckboxRadioDemo />,
      specs: [
        { token: 'checkbox.size', value: cb.size },
        { token: 'checkbox.borderRadius', value: cb.borderRadius },
        { token: 'checkbox.borderWidth', value: cb.borderWidth },
        { token: 'radio.size', value: cb.size },
      ],
    },
    {
      id: 'comp-tooltip',
      title: '提示气泡 Tooltip',
      description: '鼠标悬停时显示的提示信息，支持上/下/左/右四个方向。',
      demo: <TooltipDemo />,
      specs: [
        { token: 'padding', value: tt.padding },
        { token: 'borderRadius', value: tt.borderRadius },
        { token: 'fontSize', value: tt.fontSize },
        { token: 'arrowSize', value: tt.arrowSize },
        { token: 'offset', value: tt.offset },
      ],
    },
    {
      id: 'comp-empty',
      title: '空状态 Empty',
      description: '当列表或页面无数据时展示的占位状态，包含图标、文案和操作引导。',
      demo: <EmptyDemo />,
      specs: [
        { token: 'iconSize', value: em.iconSize },
        { token: 'titleSize', value: em.titleSize },
        { token: 'descriptionSize', value: em.descriptionSize },
        { token: 'gap', value: em.gap },
      ],
    },
    {
      id: 'comp-loading',
      title: '加载状态 Loading',
      description: '数据加载过程中的视觉反馈，包括骨架屏、旋转加载、按钮 loading 等形态。',
      demo: <LoadingDemo />,
      specs: [
        { token: 'spinnerSize', value: ld.spinnerSize },
        { token: 'spinnerStrokeWidth', value: ld.spinnerStrokeWidth },
        { token: 'skeletonRadius', value: ld.skeletonRadius },
      ],
    },
    {
      id: 'comp-badge-notification',
      title: '通知徽标 Badge / Dot',
      description: '用于标记新消息、未读数量等提示信息的徽标组件，支持数字与红点两种形态。',
      demo: <BadgeNotificationDemo />,
      specs: [
        { token: 'dotSize', value: bd.dotSize },
        { token: 'numberMinWidth', value: bd.numberMinWidth },
        { token: 'numberHeight', value: bd.numberHeight },
        { token: 'numberPadding', value: bd.numberPadding },
        { token: 'fontSize', value: bd.fontSize },
        { token: 'borderRadius', value: bd.borderRadius },
      ],
    },
  ];

  return (
    <div className="space-y-8 pt-8 border-t border-border/50">
      {components.map((comp, i) => (
        <motion.div
          key={comp.id}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.5, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
        >
          <ComponentBlock
            id={comp.id}
            title={comp.title}
            description={comp.description}
            specs={comp.specs}
          >
            {comp.demo}
          </ComponentBlock>
        </motion.div>
      ))}
    </div>
  );
}
